"Instructions to Run the News Recommendation System"

Step 1: Download and Install Requirements

1-Ensure you have Python installed on your machine (Python 3.7 or higher is recommended).

2-Download the project files and extract them into a folder (if applicable).

3-Open a terminal or command prompt and navigate to the project folder using:

""cd path_to_project_folder""
......
4-Install the required libraries by running:

""pip install -r requirements.txt""

Step 2: File Setup
Make sure the MediaStack_2090.csv file is in the project directory:

News-Recommendation-System-main/
├── main.py
├── requirements.txt
├── MediaStack_2090.csv

.....
Step 3: Run the Code
Before starting the Streamlit app, run the Python script using the following command:

""python3 main.py""

This will ensure all required files and dependencies are initialized.

.....
Step 4: Start the Streamlit Application
Run the Streamlit application using the following command:

""streamlit run main.py""

If prompted by Streamlit, you can enter your email address (optional) or leave it blank and press Enter.