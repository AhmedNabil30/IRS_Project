import streamlit as st
import pandas as pd
import numpy as np
import re
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import precision_score, recall_score, f1_score
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from scipy.stats import pearsonr
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.decomposition import TruncatedSVD

# Load NLTK resources
nltk.download('stopwords')
nltk.download('wordnet')
stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

# Load news data from CSV
csv_file_path = "MediaStack2_news.csv"

def normalize_category(category):
    """Normalize category names to ensure consistent handling"""
    category_mapping = {
        'general': 'General',
        'sports': 'Sports',
        'sport': 'Sports',
        'politics': 'Politics',
        'entertainment': 'Entertainment',
        'education': 'Education',
        'economy/finance': 'Economy/Finance',
        'economy': 'Economy/Finance',
        'finance': 'Economy/Finance',
        'health': 'Health'
    }
    if isinstance(category, str):
        category = category.lower().strip()
        return category_mapping.get(category, category.capitalize())
    return 'General'
@st.cache_data(persist=True, show_spinner=False)
def load_news_data():
    try:
        news = pd.read_csv(csv_file_path)
        news['Description'] = news['Description'].fillna('')
        news['Headline'] = news['Headline'].fillna('')
        news['Url'] = news['Url'].fillna('')
        news['Index'] = news.index
        
        # Normalize categories
        news['category'] = news['category'].apply(normalize_category)
        
        return news
    except FileNotFoundError:
        st.error("The MediaStack2_news.csv file was not found.")
        st.stop()

news = load_news_data()

def create_user_item_matrix(news_df, user_read_history):
    """Create a user-item interaction matrix"""
    user_item_matrix = pd.DataFrame(0, index=[0], columns=news_df['Headline'])
    for headline in user_read_history:
        if headline in user_item_matrix.columns:
            user_item_matrix.loc[0, headline] = 1
    return user_item_matrix

def get_collaborative_recommendations(news_df, user_item_matrix, n_components=10):
    """Generate collaborative filtering recommendations using SVD"""
    try:
        svd = TruncatedSVD(n_components=n_components, random_state=42)
        latent_matrix = svd.fit_transform(user_item_matrix)
        predicted_ratings = np.dot(latent_matrix, svd.components_)
        predictions_df = pd.DataFrame(predicted_ratings, columns=user_item_matrix.columns)
        read_articles = user_item_matrix.iloc[0] > 0
        unread_articles = predictions_df.iloc[0][~read_articles]
        return unread_articles.sort_values(ascending=False).index.tolist()
    except Exception as e:
        print(f"Error in collaborative recommendations: {str(e)}")
        return []

def calculate_pearson_similarity(user_vector1, user_vector2):
    """Calculate Pearson correlation between two user vectors"""
    correlation, _ = pearsonr(user_vector1, user_vector2)
    return correlation if not np.isnan(correlation) else 0

def get_top_n_items(item_id, item_matrix, n=5):
    """Get top N most similar items"""
    similarities = []
    for i in range(len(item_matrix)):
        if i != item_id:
            sim = calculate_pearson_similarity(item_matrix[item_id], item_matrix[i])
            similarities.append((i, sim))
    return sorted(similarities, key=lambda x: x[1], reverse=True)[:n]

def calculate_mae_rmse(predictions, actuals):
    """Calculate MAE and RMSE with empty array handling"""
    if len(predictions) == 0 or len(actuals) == 0:
        return 0.0, 0.0
    mae = mean_absolute_error(actuals, predictions)
    rmse = np.sqrt(mean_squared_error(actuals, predictions))
    return mae, rmse

def get_category_based_recommendations(news_df, user_history, num_recommendations=5):
    """Get recommendations based on user's preferred categories"""
    try:
        if not user_history:
            return []
        read_articles = news_df[news_df['Headline'].isin(user_history)]
        preferred_categories = read_articles['category'].value_counts().index.tolist()
        category_recommendations = []
        for category in preferred_categories:
            category_articles = news_df[
                (news_df['category'] == category) & 
                (~news_df['Headline'].isin(user_history))
            ]['Headline'].tolist()
            category_recommendations.extend(category_articles)
        return list(dict.fromkeys(category_recommendations))[:num_recommendations]
    except Exception as e:
        print(f"Error in category recommendations: {str(e)}")
        return []

def get_user_item_statistics(news_df, read_history):
    """Generate user and item statistics"""
    stats = {
        'total_articles': len(news_df),
        'articles_read': len(read_history),
        'reading_rate': len(read_history) / len(news_df) * 100,
        'category_breakdown': news_df[news_df['Headline'].isin(read_history)]['category'].value_counts().to_dict(),
        'top_categories': news_df[news_df['Headline'].isin(read_history)]['category'].value_counts().nlargest(3).to_dict()
    }
    return stats

def preprocess_text(text):
    text = text.lower()
    text = re.sub(r'[^a-z\s]', '', text)
    text = re.sub(r'\d+', '', text)
    words = text.split()
    words = [lemmatizer.lemmatize(word) for word in words if word not in stop_words]
    preprocessed_text = ' '.join(words)
    return preprocessed_text

def get_hybrid_recommendations(user_history, num_recommendations=5):
    """Original content-based recommendation function"""
    try:
        user_history = list(set(user_history))
        news['Processed Text'] = (news['Headline'] + ' ' + news['Description']).apply(preprocess_text)
        tfidf = TfidfVectorizer(stop_words='english', max_features=10000)
        tfidf_matrix = tfidf.fit_transform(news['Processed Text'])
        indices = pd.Series(news.index, index=news['Headline']).drop_duplicates()
        
        n_features = tfidf_matrix.shape[1]
        user_profile = np.zeros(n_features)
        valid_articles = 0
        
        for title in user_history:
            if title in indices:
                idx = indices[title]
                article_vector = tfidf_matrix[idx].toarray().flatten()
                if article_vector.shape[0] == n_features:
                    user_profile += article_vector
                    valid_articles += 1
        
        if valid_articles > 0:
            user_profile = user_profile / valid_articles
            if np.sum(user_profile) != 0:
                user_profile = user_profile / np.linalg.norm(user_profile)
        
        user_profile = user_profile.reshape(1, -1)
        cosine_sim = cosine_similarity(user_profile, tfidf_matrix).flatten()
        recommended_indices = np.argsort(cosine_sim)[::-1]
        recommended_articles = []
        
        for idx in recommended_indices:
            headline = news['Headline'].iloc[idx]
            if headline not in user_history:
                recommended_articles.append(headline)
                if len(recommended_articles) >= num_recommendations:
                    break
        
        return recommended_articles
    except Exception as e:
        print(f"Error in recommendation generation: {str(e)}")
        return []

def get_final_recommendations(news_df, user_history, num_recommendations=5):
    """Combined recommendation system using all available features"""
    try:
        # Get recommendations from different methods
        hybrid_recs = get_hybrid_recommendations(user_history, num_recommendations)
        collaborative_matrix = create_user_item_matrix(news_df, user_history)
        collab_recs = get_collaborative_recommendations(news_df, collaborative_matrix)
        category_recs = get_category_based_recommendations(news_df, user_history, num_recommendations)
        
        # Combine all recommendations
        final_recs = []
        rec_scores = {}
        
        # Weight the recommendations
        hybrid_weight = 0.4
        collab_weight = 0.3
        category_weight = 0.3
        
        # Score hybrid recommendations
        for i, rec in enumerate(hybrid_recs):
            rec_scores[rec] = rec_scores.get(rec, 0) + hybrid_weight * (1 / (i + 1))
            
        # Score collaborative recommendations
        for i, rec in enumerate(collab_recs):
            rec_scores[rec] = rec_scores.get(rec, 0) + collab_weight * (1 / (i + 1))
            
        # Score category recommendations
        for i, rec in enumerate(category_recs):
            rec_scores[rec] = rec_scores.get(rec, 0) + category_weight * (1 / (i + 1))
            
        # Sort and filter recommendations
        sorted_recs = sorted(rec_scores.items(), key=lambda x: x[1], reverse=True)
        
        # Get final recommendations
        for headline, score in sorted_recs:
            if headline not in user_history and len(final_recs) < num_recommendations:
                final_recs.append(headline)
                
        return final_recs
    except Exception as e:
        print(f"Error in final recommendations: {str(e)}")
        return []

def ndcg_at_n(recommended, actual, n):
    dcg = sum([1/np.log2(i+2) if rec in actual else 0 for i, rec in enumerate(recommended[:n])])
    idcg = sum([1/np.log2(i+2) for i in range(min(n, len(actual)))] if actual else 0)
    return dcg / idcg if idcg > 0 else 0

def map_at_n(recommended, actual, n):
    ap_sum = 0
    hit_count = 0
    for i, rec in enumerate(recommended[:n]):
        if rec in actual:
            hit_count += 1
            ap_sum += hit_count / (i + 1)
    return ap_sum / min(len(actual), n) if actual else 0

def evaluate_recommendations(recommendations, n=5):
    if not recommendations:
        return
    
    true_labels = [1 if item in st.session_state['read_history'] else 0 for item in recommendations]
    predicted_labels = [1] * len(recommendations)

    if len(true_labels) > 0:
        precision = precision_score(true_labels, predicted_labels, zero_division=1)
        recall = recall_score(true_labels, predicted_labels, zero_division=1)
        f1 = f1_score(true_labels, predicted_labels, zero_division=1)
        
        predictions = np.array(predicted_labels, dtype=float)
        actuals = np.array(true_labels, dtype=float)
        mae, rmse = calculate_mae_rmse(predictions, actuals)
        
        actual = set(st.session_state['read_history'])
        ndcg_score = ndcg_at_n(recommendations, actual, n)
        map_score = map_at_n(recommendations, actual, n)

        st.session_state['recommendation_evaluation'] = {
            'recall': recall,
            'precision': precision,
            'f1': f1,
            'ndcg@{}'.format(n): ndcg_score,
            'map@{}'.format(n): map_score,
            'mae': mae,
            'rmse': rmse
        }

# Initialize session state variables
if 'username' not in st.session_state:
    st.session_state['username'] = ''
if 'user_logged_in' not in st.session_state:
    st.session_state['user_logged_in'] = False
if 'read_history' not in st.session_state:
    st.session_state['read_history'] = []
if 'read_state' not in st.session_state:
    st.session_state['read_state'] = {}
if 'current_page' not in st.session_state:
    st.session_state['current_page'] = 0
if 'article_count' not in st.session_state:
    st.session_state['article_count'] = 15
if 'recommendation_page' not in st.session_state:
    st.session_state['recommendation_page'] = 0
if 'num_recommendations' not in st.session_state:
    st.session_state['num_recommendations'] = 10
if 'recommendations' not in st.session_state:
    st.session_state['recommendations'] = []
if 'recommendation_evaluation' not in st.session_state:
    st.session_state['recommendation_evaluation'] = {}
if 'user_stats' not in st.session_state:
    st.session_state['user_stats'] = {}

def show_login_page():
    st.title("WELCOME TO THE NEWS RECOMMENDATION SYSTEM")
    st.subheader("Please sign in to continue")
    username_input = st.text_input("Username", "")
    if st.button("Login"):
        if username_input:
            st.session_state['user_logged_in'] = True
            st.session_state['username'] = username_input
            st.success(f"Welcome, {username_input}!")
        else:
            st.warning("Please enter a username.")

def show_read_history():
    st.subheader("Your Read History")
    if st.session_state['read_history']:
        for article in st.session_state['read_history']:
            st.markdown(f"<div style='background-color: #d9d9d9; color: black; padding: 10px;margin:2px ;border-radius: 5px;'>- {article}</div>", unsafe_allow_html=True)
    else:
        st.write("No read history available.")

def show_main_interface():
    st.sidebar.header("User Menu")
    st.sidebar.markdown(f"Logged in as: {st.session_state['username']}")

    # Add category filter
    all_categories = sorted(news['category'].unique())
    selected_category = st.sidebar.selectbox(
        "Filter by Category",
        ["All Categories"] + list(all_categories)
    )

    if st.sidebar.button("View Read History"):
        show_read_history()

    if st.sidebar.button("Logout"):
        st.session_state['user_logged_in'] = False
        st.session_state['username'] = ''
        st.session_state['read_history'] = []
        st.success("Logged out successfully.")

    st.title(f"Welcome back, {st.session_state['username']}!")
    st.subheader("Browse the latest news articles")

    search_query = st.text_input("Search for articles", value="", key='search_input', placeholder="Search...")

    # Filter articles based on search query and category
    filtered_articles = news
    if search_query:
        filtered_articles = filtered_articles[filtered_articles['Headline'].str.contains(search_query, case=False, na=False)]
    if selected_category != "All Categories":
        filtered_articles = filtered_articles[filtered_articles['category'] == selected_category]

    total_articles = len(filtered_articles)
    total_pages = (total_articles // st.session_state['article_count']) + (1 if total_articles % st.session_state['article_count'] > 0 else 0)

    if total_pages > 0:
        current_page_articles = filtered_articles.iloc[
            st.session_state['current_page'] * st.session_state['article_count'] :
            (st.session_state['current_page'] + 1) * st.session_state['article_count']
        ]

        st.markdown("### Articles Found")
        for Index, article in current_page_articles.iterrows():
            color = "#d9d9d9" if article['Headline'] in st.session_state['read_state'] and st.session_state['read_state'][article['Headline']] else "#f0f0f0"
            link_color = "red" if article['Headline'] in st.session_state['read_state'] and st.session_state['read_state'][article['Headline']] else "blue"
            
            st.markdown(f"""
                <div style='background-color: {color}; color: black; padding: 15px; margin-bottom: 10px; border-radius: 5px;'>
                    <strong>{article['Headline']}</strong><br>
                    Published on: {article['Date published']}<br>
                    Category: {article['category']}<br>
                    {article['Description']}<br>
                    <a href='{article['Url']}' target='_blank' style='color: {link_color};'>Read more</a><br>
                </div>
            """, unsafe_allow_html=True)

            if st.button(f"Mark as Read", key=f"mark_read_{article['Index']}_{Index}"):
                st.session_state['read_history'].append(article['Headline'])
                st.session_state['read_state'][article['Headline']] = True

        # Pagination
        col1, col2 = st.columns(2)
        with col1:
            if st.session_state['current_page'] > 0:
                if st.button("Previous Page"):
                    st.session_state['current_page'] -= 1

        with col2:
            if st.session_state['current_page'] < total_pages - 1:
                if st.button("Next Page"):
                    st.session_state['current_page'] += 1

        st.write(f"Page {st.session_state['current_page'] + 1} of {total_pages}")

    else:
        st.write("No articles found.")

    # Generate and display recommendations
    if st.button("Generate Recommendations", key="generate_recommendations"):
        user_history = st.session_state['read_history']
        if user_history:
            recommendations = get_final_recommendations(news, user_history, num_recommendations=5)
            st.session_state['recommendations'] = recommendations
            evaluate_recommendations(recommendations)
        else:
            st.warning("Please read some articles to generate recommendations.")

    # Display Recommendations
    if st.session_state['recommendations']:
        st.subheader("Recommended Articles")
        for article in st.session_state['recommendations']:
            recommended_article = news[news['Headline'] == article]
            if not recommended_article.empty:
                article_info = recommended_article.iloc[0]
                st.markdown(f"""
                    <div style='background-color: #d9d9d9; color: black; padding: 15px; margin-bottom: 10px; border-radius: 5px;'>
                        <strong>{article_info['Headline']}</strong><br>
                        Category: {article_info['category']}<br>
                        {article_info['Description']}<br>
                        <a href='{article_info['Url']}' target='_blank' style='color: blue;'>Read more</a>
                    </div>
                """, unsafe_allow_html=True)

    # Display user statistics
    if st.session_state['read_history']:
        st.subheader("Your Reading Statistics")
        stats = get_user_item_statistics(news, st.session_state['read_history'])
        
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Articles Read", stats['articles_read'])
            st.metric("Reading Rate", f"{stats['reading_rate']:.1f}%")
        
        with col2:
            if stats['top_categories']:
                st.write("Top Categories:")
                for category, count in stats['top_categories'].items():
                    st.write(f"- {category}: {count} articles")

# Run the app
if st.session_state['user_logged_in']:
    show_main_interface()
else:
    show_login_page()
    