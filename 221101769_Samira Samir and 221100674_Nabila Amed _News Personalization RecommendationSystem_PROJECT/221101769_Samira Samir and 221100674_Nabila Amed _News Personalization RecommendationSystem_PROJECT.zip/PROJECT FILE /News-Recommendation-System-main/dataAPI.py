import requests
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer

# MediaStack API key and URL
API_KEY = "3465b82242345b1a7778b98652562e15"
url = "http://api.mediastack.com/v1/news"

# Parameters for fetching data
params = {
    'access_key': API_KEY,
    'sources': 'cnn',        # Filter for CNN
    'languages': 'en',       # English articles
    'limit': 100,            # Max articles per request
    'offset': 0              # Start offset
}

# Initialize a list for all articles
all_articles = []
desired_article_count = 2000  # Target number of articles to fetch
fetched_articles = 0          # Counter for fetched articles

# Fetch multiple pages
while fetched_articles < desired_article_count:
    print(f"Fetching articles starting at offset {params['offset']}...")
    response = requests.get(url, params=params)
    
    if response.status_code == 200:
        data = response.json()
        articles = data.get('data', [])
        
        # Break the loop if no more articles
        if not articles:
            print("No more articles available.")
            break
        
        all_articles.extend(articles)
        fetched_articles += len(articles)
        params['offset'] += 100  # Increment offset for pagination
    else:
        print(f"Error {response.status_code}: {response.json().get('error', {}).get('message', 'Unknown error')}")
        break

# Convert articles to DataFrame
if all_articles:
    news_df = pd.DataFrame(all_articles)

    # Add missing columns with default or generated values
    news_df['User ID'] = np.arange(1, len(news_df) + 1)
    news_df['Rating'] = np.random.choice([1, 2, 3, 4, 5], size=len(news_df), p=[0.2, 0.2, 0.2, 0.2, 0.2])  # Uniform distribution

    # Drop 'language' and 'country' columns if they exist
    columns_to_drop = ['language', 'country']
    for col in columns_to_drop:
        if col in news_df.columns:
            news_df.drop(columns=[col], inplace=True)

    # Rename columns for consistency
    news_df.rename(columns={
        'author': 'Author',
        'title': 'Headline',
        'description': 'Description',
        'url': 'Url',
        'published_at': 'Date published',
        'source': 'Source'
    }, inplace=True)

    # Fill missing values based on existing data
    news_df['Author'] = news_df['Author'].fillna('Unknown Author')
    news_df['Description'] = news_df['Description'].fillna('No description available.')
    news_df['Source'] = news_df['Source'].fillna('CNN')  # Example default value

    # Generate "Second header" and "Keywords"
    news_df['Second header'] = news_df['Description'].apply(lambda x: x.split('.')[0])
    def generate_keywords(text_column):
        vectorizer = TfidfVectorizer(max_features=5, stop_words='english')
        tfidf_matrix = vectorizer.fit_transform(text_column.dropna())
        feature_names = vectorizer.get_feature_names_out()
        keywords_list = []
        for i in range(tfidf_matrix.shape[0]):
            row = tfidf_matrix[i]
            keywords = [feature_names[index] for index in row.indices]
            keywords_list.append(', '.join(keywords))
        return keywords_list

    if not news_df['Description'].isnull().all():
        news_df['Keywords'] = generate_keywords(news_df['Description'])
    else:
        news_df['Keywords'] = ''

    # Add "Article text"
    news_df['Article text'] = news_df.apply(
        lambda row: f"{row['Headline']} {row['Description']}",
        axis=1
    )

    # Save the final enriched dataset
    news_df.to_csv('MediaStack_news2.csv', index=False)
    print("Dataset saved as 'MediaStack_Articles_2000.csv'")
else:
    print("No articles were fetched. Please check your API limits or query parameters.")
